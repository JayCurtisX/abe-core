# ABE Sprint 1 Backend Handoff to IOS

## 1. Files created

```txt
db/migrations/001_create_abe_intelligence_foundation.sql
db/seeds/002_seed_demo_business.sql
db/verification/003_verify_demo_seed.sql
src/db.js
src/dashboard.mapper.js
src/dashboard.service.js
src/dashboard.route.example.ts
src/server.js
tests/dashboard.contract.test.js
package.json
.env.example
README.md
example-dashboard-response.json
```

## 2. Commands to run migrations

```bash
export DATABASE_URL="postgres://postgres:postgres@localhost:5432/abe_demo"
npm install
npm run db:migrate
```

Equivalent direct command:

```bash
psql "$DATABASE_URL" -f db/migrations/001_create_abe_intelligence_foundation.sql
```

## 3. Commands to seed the database

```bash
npm run db:seed
npm run db:verify
```

Equivalent direct commands:

```bash
psql "$DATABASE_URL" -f db/seeds/002_seed_demo_business.sql
psql "$DATABASE_URL" -f db/verification/003_verify_demo_seed.sql
```

## 4. Commands to start the backend

```bash
export DATABASE_URL="postgres://postgres:postgres@localhost:5432/abe_demo"
export PORT=3001
npm start
```

## 5. Dashboard endpoint URL

```txt
GET http://localhost:3001/api/workspaces/00000000-0000-0000-0000-000000000001/dashboard
```

Invalid workspace check:

```txt
GET http://localhost:3001/api/workspaces/11111111-1111-1111-1111-111111111111/dashboard
```

## 6. Example JSON response

```json
{
  "workspaceId": "00000000-0000-0000-0000-000000000001",
  "businessState": {
    "state": "Growth Constraint Mode",
    "why": "The business has demand, but follow-up is delayed.",
    "confidence": 82,
    "biggestConstraint": "Lead follow-up",
    "biggestOpportunity": "Convert warm leads into booked calls",
    "nextAction": "Prepare follow-up drafts and same-day call tasks"
  },
  "metrics": {
    "newLeads": 12,
    "contactedLeads": 4,
    "uncontactedLeads": 8,
    "overdueTasks": 7,
    "estimatedPipeline": 32000,
    "goal": "Book 20 sales calls"
  },
  "recentActivity": [
    {
      "id": "a0000000-0000-0000-0000-000000000001",
      "label": "12 new leads entered the system",
      "timestamp": "2026-07-10T09:00:00"
    },
    {
      "id": "a0000000-0000-0000-0000-000000000002",
      "label": "ABE identified Growth Constraint Mode",
      "timestamp": "2026-07-10T09:01:00"
    }
  ],
  "dataLabel": "Demo Data"
}
```

## 7. Test results

Local contract tests passed:

```txt
pass: dashboard response matches Developer B contract
pass: invalid workspace returns no dashboard payload for route-level 404 handling
pass: dashboard service queries are scoped by workspace_id
```

Command used:

```bash
npm test
```

Result:

```txt
3 tests passed
0 failed
```

## 8. Blockers

No existing backend repository or running Postgres server was available in this environment. Because of that, database migration execution and endpoint integration against a live Postgres instance must be run by IOS or the developer in the actual backend environment.

What was verified locally:

```txt
Dashboard JSON contract mapping passed.
Invalid workspace behavior is implemented as a 404 response.
Dashboard service queries are scoped by workspace_id.
Files are ready for backend implementation.
```

What still needs live environment verification:

```txt
psql migration execution
psql seed execution
GET endpoint call against seeded Postgres data
invalid workspace endpoint call against seeded Postgres data
```

## Sprint 1 Status

Ready for IOS or the backend developer to run against Postgres.

Developer B can connect once the backend is started and the seed has been applied.
